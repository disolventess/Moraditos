import { useRef } from "react";
import Icon from "./Icons";
import s from "./Header.module.css";

type Props = {
  dark: boolean;
  onTheme: () => void;
  onSelect: (index: number) => void;
  panelHref: string;
};
export default function Header({ dark, onTheme, onSelect, panelHref }: Props) {
  const menu = useRef<HTMLDetailsElement>(null);
  function closeMenu() {
    if (menu.current) menu.current.open = false;
  }
  const links = (
    <>
      <a href="#como-funciona" onClick={closeMenu}>
        CÓMO FUNCIONA
      </a>
      <button
        onClick={() => {
          onSelect(0);
          closeMenu();
        }}
      >
        PARA NEGOCIOS
      </button>
      <button
        onClick={() => {
          onSelect(1);
          closeMenu();
        }}
      >
        PARA STREAMERS
      </button>
      <a href="#preguntas-frecuentes" onClick={closeMenu}>
        PREGUNTAS FRECUENTES
      </a>
    </>
  );
  const panel = (
    <a className={s.panel} href={panelHref}>
      <Icon name="grid" />
      Panel de control
    </a>
  );
  return (
    <header className={s.header}>
      <a className={s.logo} href="/" aria-label="Moraditos, inicio">
        <img src="/hero/symbol.svg" width="72" height="55" alt="" />
        <span>oraditos</span>
      </a>
      <div className={s.bar}>
        <nav className={s.desktop} aria-label="Navegación principal">
          {links}
        </nav>
        <button
          className={s.theme}
          onClick={onTheme}
          aria-label={dark ? "Activar modo claro" : "Activar modo oscuro"}
        >
          <Icon name="sun" className={!dark ? s.selected : undefined} />
          <Icon name="moon" className={dark ? s.selected : undefined} />
        </button>
        <div className={s.desktopPanel}>{panel}</div>
        <details
          ref={menu}
          className={s.mobile}
          onKeyDown={(e) => {
            if (e.key === "Escape") {
              closeMenu();
              menu.current?.querySelector("summary")?.focus();
            }
          }}
        >
          <summary aria-label="Abrir menú">
            <span />
            <span />
            <span />
          </summary>
          <nav aria-label="Navegación móvil">
            {links}
            {panel}
          </nav>
        </details>
      </div>
    </header>
  );
}
