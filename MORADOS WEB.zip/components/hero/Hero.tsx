"use client";

import { useEffect, useState } from "react";
import Header from "./Header";
import HeroCopy from "./HeroCopy";
import HeroScene from "./HeroScene";
import HeroControls from "./HeroControls";
import { slides } from "./slides";
import s from "./Hero.module.css";

type Props = { ctaHref?: string; panelHref?: string; scrollTarget?: string };
export default function Hero({
  ctaHref = "/registro",
  panelHref = "/panel",
  scrollTarget = "#como-funciona",
}: Props) {
  const [active, setActive] = useState(0);
  const [dark, setDark] = useState(false);
  useEffect(() => {
    try {
      setDark(localStorage.getItem("moraditos-theme") === "dark");
    } catch {
      /* Storage may be blocked. */
    }
  }, []);
  function toggleTheme() {
    const next = !dark;
    setDark(next);
    try {
      localStorage.setItem("moraditos-theme", next ? "dark" : "light");
    } catch {
      /* Keep theme in memory. */
    }
  }
  return (
    <section
      className={s.hero}
      data-theme={dark ? "dark" : "light"}
      aria-label="Moraditos para negocios y streamers"
      aria-roledescription="carrusel"
    >
      <div className={s.waves} aria-hidden="true" />
      <Header
        dark={dark}
        onTheme={toggleTheme}
        onSelect={setActive}
        panelHref={panelHref}
      />
      <div className={s.body} id="hero-content">
        <HeroCopy slide={slides[active]} ctaHref={ctaHref} />
        <HeroScene active={active} />
      </div>
      <p className={s.srOnly} aria-live="polite" aria-atomic="true">
        {active + 1} de {slides.length}: {slides[active].label}
      </p>
      <HeroControls
        active={active}
        onSelect={setActive}
        scrollTarget={scrollTarget}
      />
    </section>
  );
}
